# HANDOFF 增量 — 证据打包完成

当前已完成证据回拷和本地审计，停于 **acceptance 门禁**，等待小co / Architect；未自行登记通过或追加审查。

- 17:11 reviewer 已通过回拷 error；清单采集改用已确认可执行的 openpi .venv 绝对路径。
- 4239 个远端文件逐文件 SHA256 相符；完整 formal/preflight/server 日志、trials、summary、heldout、protocol、environment、75 个视频已回拷。
- 本地独立复算 2000/2000：A29999 487/500（97.4%）；G0 248/500（49.6%）；G1 285/500（57.0%，+7.4pp）；G2 223/500（44.6%，−5.0pp）。每组每任务 50 次；无缺失、重复、执行异常或重试；采数内容交集为 0。
- 正式 67 + 预跑 8 个视频全帧解码通过；原 G0/G1 有效 loss CSV 各 50 个唯一递增 steps，3 PNG 解码通过，原文件保留。
- 验收材料：../pnp-heldout-acceptance-evidence.md；原始和独立汇总均在当前目录。冻结协议/评测脚本未改；未重训、重评或删除保护资产。
- state 只读快照：reviews_used=4 / max_reviews=6；由编排管理后续验收，不沿用旧的固定三次表述。

原任务目录不可写；请编排同步该状态及最终验收材料。
